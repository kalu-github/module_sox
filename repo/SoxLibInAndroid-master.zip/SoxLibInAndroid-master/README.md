# SoxLibInAndroid

I edited some sox source file,such as sox.c sox.h formats.c and CMakeLists.txt. you can Use Library like command .