#define PACKAGE_VERSION "14.4.2git"

/* #undef EXTERNAL_GSM */
/* #undef EXTERNAL_LPC10 */
/* #undef HAVE_ALSA */
/* #undef HAVE_AMRNB */
/* #undef HAVE_AMRWB */
/* #undef HAVE_AO */
#define HAVE_BYTESWAP_H          1
/* #undef HAVE_COREAUDIO */
#define HAVE_FENV_H              1
/* #undef HAVE_FLAC */
/* #undef HAVE_FMEMOPEN */
#define HAVE_FSEEKO              1
#define HAVE_GETTIMEOFDAY        1
#define HAVE_GLOB_H              1
#define HAVE_GSM                      1
/* #undef HAVE_ID3TAG */
#define HAVE_INTTYPES_H          1
/* #undef HAVE_IO_H */
/* #undef HAVE_LAME_LAME_H */
/* #undef HAVE_LAME_SET_VBR_QUALITY */
#define HAVE_LPC10                    1
#define HAVE_LRINT               1
/* #undef HAVE_LTDL_H */
/* #undef HAVE_MACHINE_SOUNDCARD_H */
/* #undef HAVE_MAD_H */
/* #undef HAVE_MAGIC */
#define HAVE_MKSTEMP             1
/* #undef HAVE_MP3 */
/* #undef HAVE_OGG_VORBIS */
/* #undef HAVE_OSS */
/* #undef HAVE_PNG */
#define HAVE_POPEN               1
/* #undef HAVE_PULSEAUDIO */
/* #undef HAVE_SNDFILE */
/* #undef HAVE_SNDFILE_1_0_18 */
/* #undef HAVE_SNDIO */
/* #undef HAVE_SPEEXDSP */
#define HAVE_STDINT_H            1
#define HAVE_STRCASECMP          1
#define HAVE_STRING_H            1
#define HAVE_STRINGS_H           1
/* #undef HAVE_STRRSTR */
/* #undef HAVE_SUN_AUDIO */
/* #undef HAVE_SUN_AUDIOIO_H */
/* #undef HAVE_SYS_AUDIOIO_H */
/* #undef HAVE_SYS_SOUNDCARD_H */
#define HAVE_SYS_STAT_H          1
/* #undef HAVE_SYS_TIMEB_H */
#define HAVE_SYS_TIME_H          1
#define HAVE_SYS_TYPES_H         1
#define HAVE_SYS_UTSNAME_H       1
#define HAVE_TERMIOS_H           1
#define HAVE_UNISTD_H            1
#define HAVE_VSNPRINTF           1
/* #undef HAVE_WAVPACK */
/* #undef WORDS_BIGENDIAN */
